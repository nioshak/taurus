// src/components/SignupPage.js
import { useState } from "react";
import axios from "axios";

export default function SignupPage() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/signup", form, {
        withCredentials: true,
      });
      window.location.href = "/dashboard";
    } catch (err) {
      setError("Signup failed. Please check your info and try again.");
    }
  };

  return (
    <div className="relative min-h-screen bg-black overflow-hidden flex items-center justify-center px-4">
      {/* Background: dashboard overlay image or animated preview */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover opacity-20 blur-sm z-0"
      >
        <source src="/screenshots/preview.mp4" type="video/mp4" />
      </video>

      {/* Logo in top-left corner */}
      <div className="absolute top-6 left-6 z-20">
        <a href="/">
          <img
            src="/logos/33.png" // <-- update path to your actual logo
            alt="Taurus Space Logo"
            className="h-14 w-auto hover:opacity-80 transition duration-200"
          />
        </a>
      </div>

      {/* Glassmorphism Sign-up Box */}
      <div className="relative z-10 max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Left side (tagline) */}
        <div className="hidden md:block text-white">
          <h1 className="text-4xl font-bold leading-snug mb-4">Collision-Free Orbits</h1>
          <p className="text-lg text-gray-300">Join Taurus Space to monitor, maneuver, and avoid. Real-time data feeds at your command.</p>
        </div>

        {/* Right side (form) */}
        <form
          onSubmit={handleSubmit}
          className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-white/20 w-full"
        >
          <h2 className="text-3xl font-bold text-green-400 mb-6">Create Your Account</h2>
          <input
            type="email"
            placeholder="Email"
            className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          <button
            type="submit"
            className="w-full py-2 bg-green-500 hover:bg-green-600 rounded-lg text-black font-semibold transition duration-200"
          >
            Sign Up
          </button>
          <p className="mt-4 text-sm text-gray-300 text-center">
            Already have an account?{" "}
            <a href="/login" className="text-green-400 hover:underline">
              Sign in
            </a>
          </p>
        </form>
      </div>
    </div>
  );
}
