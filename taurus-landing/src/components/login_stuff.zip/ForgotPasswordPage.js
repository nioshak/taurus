// src/components/ForgotPasswordPage.js
import { useState } from "react";
import axios from "axios";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/forgot-password", { email });
      setStatus("If an account exists, reset instructions were sent.");
      setError("");
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Try again later.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-white/20 max-w-md w-full"
      >
        <h2 className="text-3xl font-bold mb-6 text-center" style={{ color: "#008bcc" }}>
          Forgot Password
        </h2>
        <input
          type="email"
          placeholder="Enter your email"
          className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        {status && <p className="text-green-400 text-sm mb-4">{status}</p>}
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        <button
          type="submit"
          className="w-full py-2 rounded-lg text-white font-semibold"
          style={{ backgroundColor: "#008bcc" }}
        >
          Send Reset Link
        </button>
      </form>
    </div>
  );
}
