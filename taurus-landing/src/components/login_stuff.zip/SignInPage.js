// src/components/SigninPage.js
import { useState, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../contexts/AuthContext";

export default function SigninPage() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/login", form, {
        withCredentials: true,
      });

      const userRes = await axios.get("http://localhost:5000/api/user", {
        withCredentials: true,
      });

      setUser(userRes.data);
      navigate("/dashboard");
    } catch (err) {
      console.error("Login failed:", err);
      setError("Invalid email or password.");
    }
  };

  return (
    <div className="relative min-h-screen bg-black overflow-hidden flex items-center justify-center px-4">
      {/* Background overlay image */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-20 blur-sm"
        style={{
          backgroundImage: `url('/screenshots/dashboard.png')`,
        }}
      ></div>

      {/* Logo in top-left corner */}
      <div className="absolute top-6 left-6 z-20">
        <a href="/">
          <img
            src="/logos/33.png" // <-- update path to your actual logo
            alt="Taurus Space Logo"
            className="h-14 w-auto hover:opacity-80 transition duration-200"
          />
        </a>
      </div>

      {/* Glassmorphism Login Container */}
      <div className="relative z-10 max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Left side (headline or value prop) */}
        <div className="hidden md:block text-white">
          <h1 className="text-4xl font-bold leading-snug mb-4">Access Mission Control</h1>
          <p className="text-lg text-gray-300">Sign in to monitor and respond to real-time satellite events with precision.</p>
        </div>

        {/* Right side (form) */}
        <form
          onSubmit={handleLogin}
          className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-white/20 w-full"
        >
          <h2 className="text-3xl font-bold mb-6" style={{ color: "#008bcc" }}>Sign In</h2>
          <input
            type="email"
            placeholder="Email"
            className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
          <p className="text-sm text-right mb-4">
            <a
              href="/forgot-password"
              className="hover:underline text-gray-300"
              style={{ color: "#008bcc" }}
            >
              Forgot password?
            </a>
          </p>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          <button
            type="submit"
            className="w-full py-2 rounded-lg text-white font-semibold transition duration-200"
            style={{
              backgroundColor: "#008bcc",
              hover: "#007ab3", // optional if using inline hover logic
            }}
          >
            Sign In
          </button>
          <p className="mt-4 text-sm text-gray-300 text-center">
            Don’t have an account?{" "}
            <a
              href="/signup"
              className="hover:underline"
              style={{ color: "#008bcc" }}
            >
              Sign up
            </a>
          </p>
        </form>
      </div>
    </div>
  );
}
