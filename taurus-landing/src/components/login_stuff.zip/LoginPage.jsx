// src/components/LoginPage.jsx
export default function LoginPage() {
  return <h2 style={{ padding: '2rem' }}>Sign In (Coming Soon)</h2>;
}
