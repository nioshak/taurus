// src/components/ResetPasswordPage.js
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const token = searchParams.get("token");

  const handleReset = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/reset-password", {
        token,
        password,
        }, {
          withCredentials: true,
      });
      setStatus("Password reset successful. You can now sign in.");
      setError("");
    } catch (err) {
      console.error(err);
      const msg = err.response?.data?.error || "Something went wrong.";
      setError(msg);
      setStatus("");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-4">
      <form
        onSubmit={handleReset}
        className="bg-white/10 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-white/20 max-w-md w-full"
      >
        <h2 className="text-3xl font-bold mb-6 text-center" style={{ color: "#008bcc" }}>
          Reset Password
        </h2>
        <input
          type="password"
          placeholder="Enter new password"
          className="w-full mb-4 px-4 py-2 rounded-lg bg-gray-800/70 text-white placeholder-gray-400 focus:outline-none"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {status && <p className="text-green-400 text-sm mb-4">{status}</p>}
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        <button
          type="submit"
          className="w-full py-2 rounded-lg text-white font-semibold"
          style={{ backgroundColor: "#008bcc" }}
        >
          Reset Password
        </button>
      </form>
    </div>
  );
}
